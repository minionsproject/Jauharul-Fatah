import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Feedback extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -1),
          end: Alignment(0, 1),
          colors: <Color>[Color(0xFF352163), Color(0xFF331972), Color(0xFF33143C)],
          stops: <double>[0, 0.578, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -86,
            top: -170.5,
            child: Opacity(
              opacity: 0.5,
              child: ClipRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 40,
                    sigmaY: 40,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      backgroundBlendMode: BlendMode.softLight,
                      image: DecorationImage(
                        image: AssetImage(
                          'assets/images/image.jpeg',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 493,
                      height: 1031,
                    ),
                  ),
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(15, 11.5, 15, 0),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 76,
                  child: Opacity(
                    opacity: 0.5,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        gradient: LinearGradient(
                          begin: Alignment(0, -1),
                          end: Alignment(0, 1),
                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                          stops: <double>[0, 1],
                        ),
                      ),
                      child: Container(
                        width: 387,
                        height: 41,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 17),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0.5, 6, 0),
                              child: SizedBox(
                                width: 324.6,
                                child: Text(
                                  '9:41',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 12,
                                    height: 1,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0.5),
                              child: SizedBox(
                                width: 56.4,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 6.6, 0),
                                      width: 13.9,
                                      height: 12,
                                      child: SizedBox(
                                        width: 13.9,
                                        height: 12,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_1_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0.8, 6, 0.8),
                                      width: 15,
                                      height: 10.5,
                                      child: SizedBox(
                                        width: 15,
                                        height: 10.5,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_11_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 3.3, 0, 1.3),
                                      width: 15,
                                      height: 7.5,
                                      child: SizedBox(
                                        width: 15,
                                        height: 7.5,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_3_x2.svg',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            width: 238.7,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  width: 35,
                                  height: 35,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(11.1, 11.9, 10, 13.1),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        Container(
                                          width: 13.9,
                                          height: 10,
                                          child: SizedBox(
                                            width: 13.9,
                                            height: 10,
                                            child: SvgPicture.asset(
                                              'assets/vectors/vector_7_x2.svg',
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          bottom: -13.1,
                                          child: Container(
                                            width: 35,
                                            height: 35,
                                            child: Opacity(
                                              opacity: 0.3,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: Color(0xFFFFFFFF),
                                                  borderRadius: BorderRadius.circular(5),
                                                ),
                                                child: Container(
                                                  width: 35,
                                                  height: 35,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 11, 0, 12),
                                  child: Text(
                                    'Feedback',
                                    style: GoogleFonts.getFont(
                                      'Poppins',
                                      fontWeight: FontWeight.w600,
                                      fontSize: 18,
                                      height: 0.7,
                                      color: Color(0xFFFFFFFF),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 25.5, 30),
                        child: Text(
                          'Your feedback can help everyone see more 
                      accurate weather conditions!',
                          style: GoogleFonts.getFont(
                            'Poppins',
                            fontWeight: FontWeight.w400,
                            fontSize: 16,
                            height: 1.4,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 7, 40),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 40, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0x3B030303),
                                          borderRadius: BorderRadius.circular(50),
                                        ),
                                        child: Container(
                                          height: 100,
                                          padding: EdgeInsets.fromLTRB(1, 23, 0, 24),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  'assets/images/download_1.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 57,
                                              height: 53,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0.1, 0, 0, 0),
                                      child: Text(
                                        'Sunny',
                                        style: GoogleFonts.getFont(
                                          'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 0.8,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 40, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0x3B030303),
                                          borderRadius: BorderRadius.circular(50),
                                        ),
                                        child: Container(
                                          width: 100,
                                          height: 100,
                                          padding: EdgeInsets.fromLTRB(16, 15, 15, 16),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/rainy_weather_4034172333733601.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 69,
                                              height: 69,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0.7, 0),
                                      child: Text(
                                        'Cloudy',
                                        style: GoogleFonts.getFont(
                                          'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 0.8,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0x3B030303),
                                        borderRadius: BorderRadius.circular(50),
                                      ),
                                      child: Container(
                                        width: 100,
                                        height: 100,
                                        padding: EdgeInsets.fromLTRB(16, 15, 15, 16),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: AssetImage(
                                                'assets/images/rain_331175327548872.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            width: 69,
                                            height: 69,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0.4, 0),
                                    child: Text(
                                      'Rain',
                                      style: GoogleFonts.getFont(
                                        'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                        height: 0.8,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 7, 286),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 40, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0x3B030303),
                                          borderRadius: BorderRadius.circular(50),
                                        ),
                                        child: Container(
                                          width: 100,
                                          height: 100,
                                          padding: EdgeInsets.fromLTRB(12, 11, 11, 12),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/rainy_weather_4034172333733602.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 77,
                                              height: 77,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0),
                                      child: Text(
                                        'Snow',
                                        style: GoogleFonts.getFont(
                                          'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 0.8,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 40, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Color(0x3B030303),
                                          borderRadius: BorderRadius.circular(50),
                                        ),
                                        child: Container(
                                          width: 100,
                                          height: 100,
                                          padding: EdgeInsets.fromLTRB(10, 9, 9, 10),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/rainy_weather_40341723337336021.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 81,
                                              height: 81,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0.6, 0, 0, 0),
                                      child: Text(
                                        'Storm',
                                        style: GoogleFonts.getFont(
                                          'Poppins',
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          height: 0.8,
                                          color: Color(0xFFFFFFFF),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0x3B030303),
                                        borderRadius: BorderRadius.circular(50),
                                      ),
                                      child: Container(
                                        width: 100,
                                        height: 100,
                                        padding: EdgeInsets.fromLTRB(8, 7, 7, 8),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: AssetImage(
                                                'assets/images/cloud_rain_and_lightning_544561745516112.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            width: 85,
                                            height: 85,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(16, 0, 17, 0),
                                    child: Text(
                                      'Thunder',
                                      style: GoogleFonts.getFont(
                                        'Poppins',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16,
                                        height: 0.8,
                                        color: Color(0xFFFFFFFF),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0.7, 0, 0, 40),
                        child: Text(
                          'Submit',
                          style: GoogleFonts.getFont(
                            'Poppins',
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            height: 0.8,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(1, 0, 0, 0),
                        child: SizedBox(
                          width: 300,
                          height: 50,
                          child: SvgPicture.asset(
                            'assets/vectors/footer_menu_1_x2.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}