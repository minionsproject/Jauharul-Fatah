import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -1),
          end: Alignment(0, 1),
          colors: <Color>[Color(0xFF352163), Color(0xFF331972), Color(0xFF33143C)],
          stops: <double>[0, 0.578, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -76,
            top: -170.5,
            child: Opacity(
              opacity: 0.5,
              child: ClipRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 40,
                    sigmaY: 40,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      backgroundBlendMode: BlendMode.softLight,
                      image: DecorationImage(
                        image: AssetImage(
                          'assets/images/image.jpeg',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 493,
                      height: 1031,
                    ),
                  ),
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(15, 11.5, 0, 0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 17),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0.5, 6, 0),
                        child: SizedBox(
                          width: 324.6,
                          child: Text(
                            '9:41',
                            style: GoogleFonts.getFont(
                              'Poppins',
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              height: 1,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0.5),
                        child: SizedBox(
                          width: 56.4,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 6.6, 0),
                                width: 13.9,
                                height: 12,
                                child: SizedBox(
                                  width: 13.9,
                                  height: 12,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_6_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0.8, 6, 0.8),
                                width: 15,
                                height: 10.5,
                                child: SizedBox(
                                  width: 15,
                                  height: 10.5,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_10_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 3.3, 0, 1.3),
                                width: 15,
                                height: 7.5,
                                child: SizedBox(
                                  width: 15,
                                  height: 7.5,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_x2.svg',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Opacity(
                        opacity: 0.3,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFFFFFFF),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: SizedBox(
                            width: 35,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(9.7, 9.7, 9.7, 9.7),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 3.9),
                                    child: SizedBox(
                                      width: 15.6,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 3.9, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFFFFFFFF),
                                                borderRadius: BorderRadius.circular(1),
                                              ),
                                              child: Container(
                                                width: 5.8,
                                                height: 5.8,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFFFFFFFF),
                                              borderRadius: BorderRadius.circular(1),
                                            ),
                                            child: Container(
                                              width: 5.8,
                                              height: 5.8,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    child: SizedBox(
                                      width: 15.6,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 3.9, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: Color(0xFFFFFFFF),
                                                borderRadius: BorderRadius.circular(1),
                                              ),
                                              child: Container(
                                                width: 5.8,
                                                height: 5.8,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFFFFFFFF),
                                              borderRadius: BorderRadius.circular(1),
                                            ),
                                            child: Container(
                                              width: 5.8,
                                              height: 5.8,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 10, 0, 11),
                        child: Text(
                          'Surat',
                          style: GoogleFonts.getFont(
                            'Poppins',
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            height: 1,
                            color: Color(0xFFFFFFFF),
                          ),
                        ),
                      ),
                      Opacity(
                        opacity: 0.3,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFFFFFFF),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Container(
                            width: 35,
                            height: 35,
                            padding: EdgeInsets.fromLTRB(9.7, 9.7, 9.7, 9.7),
                            child: Container(
                              width: 15.6,
                              height: 15.6,
                              child: SizedBox(
                                width: 15.6,
                                height: 15.6,
                                child: SvgPicture.asset(
                                  'assets/vectors/vector_15_x2.svg',
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 16.3, 19),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0.2, 18),
                        child: Text(
                          'Mostly Sunny',
                          style: GoogleFonts.getFont(
                            'Poppins',
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                            height: 1.4,
                            color: Color(0xFFDEDDDD),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(2, 0, 1.7, 28),
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(
                              'assets/images/cloudy_weather_331175827548928.png',
                            ),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x1AFFFFFF),
                              offset: Offset(0, 4),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                        child: Container(
                          width: 172,
                          height: 139,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(13.3, 0, 0, 6),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 14, 0),
                          child: Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Text(
                                '23',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 81,
                                  height: 1,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: Container(
                                  width: 16,
                                  height: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Text(
                        'Friday, 26 August 2022 | 10:00',
                        style: GoogleFonts.getFont(
                          'Poppins',
                          fontWeight: FontWeight.w500,
                          fontSize: 12,
                          height: 1.4,
                          color: Color(0xFFDEDDDD),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
                  child: Stack(
                    children: [
                      Positioned(
                        top: -13,
                        child: Opacity(
                          opacity: 0.5,
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              gradient: LinearGradient(
                                begin: Alignment(0, -1),
                                end: Alignment(0, 1),
                                colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                stops: <double>[0, 1],
                              ),
                            ),
                            child: Container(
                              width: 294,
                              height: 95,
                            ),
                          ),
                        ),
                      ),
                Container(
                        padding: EdgeInsets.fromLTRB(19, 13, 18.1, 14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 25, 0),
                              child: SizedBox(
                                width: 78,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(2.4, 0, 0, 17),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(3, 0, 5.4, 6),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage(
                                                    'assets/images/insurance_12.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                width: 24,
                                                height: 24,
                                              ),
                                            ),
                                          ),
                                          Text(
                                            '30% ',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 14,
                                              color: Color(0xFFFFFFFF),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Positioned(
                                        bottom: -17,
                                        child: SizedBox(
                                          height: 18,
                                          child: Text(
                                            'Precipitation',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12,
                                              color: Color(0xFFDEDDDD),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 25.2, 0),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(13, 0, 10.8, 17),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(3, 0, 5, 6),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/insurance_11.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 24,
                                              height: 24,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          '20% ',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Positioned(
                                      bottom: -17,
                                      child: SizedBox(
                                        height: 18,
                                        child: Text(
                                          'Humidity',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12,
                                            color: Color(0xFFDEDDDD),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Container(
                                padding: EdgeInsets.fromLTRB(12, 0, 13.3, 17),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(12, 0, 11.7, 6),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/insurance_1.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 24,
                                              height: 24,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          '9km/h',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Positioned(
                                      bottom: -17,
                                      child: SizedBox(
                                        height: 18,
                                        child: Text(
                                          'Wind Speed',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12,
                                            color: Color(0xFFDEDDDD),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 4, 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(5, 0, 6.2, 11),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                              child: SizedBox(
                                width: 278,
                                child: Text(
                                  'Today',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12,
                                    height: 1.5,
                                    color: Color(0xFFDEDDDD),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                              child: Text(
                                '7-Day Forecasts',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12,
                                  height: 1.5,
                                  color: Color(0xFFDEDDDD),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: Stack(
                                children: [
                                Positioned(
                                  left: -11,
                                  right: -10,
                                  top: -10,
                                  bottom: -10,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          Container(
                                    padding: EdgeInsets.fromLTRB(11, 10, 10, 10),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 2.7, 3),
                                          child: Text(
                                            '10 AM',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12,
                                              height: 1.5,
                                              color: Color(0xFFDEDDDD),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  'assets/images/cloudy_weather_331175827548928.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 37,
                                              height: 30,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(9, 0, 9, 0),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0.9, 0),
                                                  child: Text(
                                                    '23',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 12,
                                                      height: 1.5,
                                                      color: Color(0xFFDEDDDD),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 11),
                                                  width: 2,
                                                  height: 2,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: Stack(
                                children: [
                                Positioned(
                                  left: -11,
                                  right: -13.5,
                                  top: -10,
                                  bottom: -10,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          Container(
                                    padding: EdgeInsets.fromLTRB(11, 10, 13.5, 10),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        SizedBox(
                                          width: double.infinity,
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0, 43),
                                                child: Text(
                                                  '12 AM',
                                                  style: GoogleFonts.getFont(
                                                    'Poppins',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 12,
                                                    height: 1.5,
                                                    color: Color(0xFFDEDDDD),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(9, 0, 7.5, 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      margin: EdgeInsets.fromLTRB(0, 0, 0.9, 0),
                                                      child: Text(
                                                        '23',
                                                        style: GoogleFonts.getFont(
                                                          'Poppins',
                                                          fontWeight: FontWeight.w600,
                                                          fontSize: 12,
                                                          height: 1.5,
                                                          color: Color(0xFFDEDDDD),
                                                        ),
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Container(
                                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 11),
                                                        height: 2,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Positioned(
                                          left: -4,
                                          right: -6.5,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                fit: BoxFit.cover,
                                                image: AssetImage(
                                                  'assets/images/rainy_weather_4034172333733601.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 44,
                                              height: 44,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: Stack(
                                children: [
                                Positioned(
                                  left: -11,
                                  right: -7,
                                  top: -10,
                                  bottom: -10,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          Container(
                                    padding: EdgeInsets.fromLTRB(11, 10, 7, 10),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(4, 0, 10.7, 3),
                                          child: Text(
                                            '1 PM',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12,
                                              height: 1.5,
                                              color: Color(0xFFDEDDDD),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              fit: BoxFit.cover,
                                              image: AssetImage(
                                                'assets/images/rainy_weather_4034172333733601.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            width: 40,
                                            height: 40,
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(9, 0, 9, 0),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0.9, 0),
                                                  child: Text(
                                                    '23',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 12,
                                                      height: 1.5,
                                                      color: Color(0xFFDEDDDD),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 11),
                                                  width: 2,
                                                  height: 2,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: Stack(
                                children: [
                                Positioned(
                                  left: -14,
                                  right: -15.9,
                                  top: -10,
                                  bottom: 0,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          SizedBox(
                                    height: 99,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(14, 10, 15.9, 0),
                                      child: Stack(
                                        clipBehavior: Clip.none,
                                        children: [
                                          Positioned(
                                            left: -10,
                                            right: -12.9,
                                            child: Container(
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage(
                                                    'assets/images/cloud_rain_and_lightning_544561745516112.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                width: 51,
                                                height: 51,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: double.infinity,
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.end,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 48),
                                                  child: Text(
                                                    '3 PM',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 12,
                                                      height: 1.5,
                                                      color: Color(0xFFDEDDDD),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(5.1, 0, 5.1, 0),
                                                  width: 2,
                                                  height: 2,
                                                  child: Container(
                                                    width: 2,
                                                    height: 2,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: 6,
                                            bottom: 10,
                                            child: SizedBox(
                                              height: 18,
                                              child: Text(
                                                '23',
                                                style: GoogleFonts.getFont(
                                                  'Poppins',
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 12,
                                                  height: 1.5,
                                                  color: Color(0xFFDEDDDD),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                              child: Stack(
                                children: [
                                Positioned(
                                  left: -9,
                                  right: -10,
                                  top: -10,
                                  bottom: -10,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          Container(
                                    padding: EdgeInsets.fromLTRB(9, 10, 10, 10),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.fromLTRB(5, 0, 5.3, 2),
                                          child: Text(
                                            '5 PM',
                                            style: GoogleFonts.getFont(
                                              'Poppins',
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12,
                                              height: 1.5,
                                              color: Color(0xFFDEDDDD),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              image: DecorationImage(
                                                image: AssetImage(
                                                  'assets/images/rain_331175327548872.png',
                                                ),
                                              ),
                                            ),
                                            child: Container(
                                              width: 39,
                                              height: 39,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          margin: EdgeInsets.fromLTRB(11, 0, 11, 0),
                                          child: Align(
                                            alignment: Alignment.topLeft,
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0.9, 0),
                                                  child: Text(
                                                    '23',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 12,
                                                      height: 1.5,
                                                      color: Color(0xFFDEDDDD),
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 5, 0, 11),
                                                  width: 2,
                                                  height: 2,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Stack(
                              children: [
                                Positioned(
                                  left: -9,
                                  right: -10,
                                  top: -10,
                                  bottom: -10,
                                  child: Opacity(
                                    opacity: 0.5,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        gradient: LinearGradient(
                                          begin: Alignment(0, -1),
                                          end: Alignment(0, 1),
                                          colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                          stops: <double>[0, 1],
                                        ),
                                      ),
                                      child: Container(
                                        width: 58,
                                        height: 99,
                                      ),
                                    ),
                                  ),
                                ),
                          Container(
                                  padding: EdgeInsets.fromLTRB(9, 10, 10, 10),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(2, 0, 4, 2),
                                        child: Text(
                                          '10 PM',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12,
                                            height: 1.5,
                                            color: Color(0xFFDEDDDD),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 2),
                                        child: Container(
                                          decoration: BoxDecoration(
                                            image: DecorationImage(
                                              image: AssetImage(
                                                'assets/images/rain_331175327548872.png',
                                              ),
                                            ),
                                          ),
                                          child: Container(
                                            width: 39,
                                            height: 39,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(11, 0, 11, 0),
                                        child: Align(
                                          alignment: Alignment.topLeft,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 0, 0.9, 0),
                                                child: Text(
                                                  '23',
                                                  style: GoogleFonts.getFont(
                                                    'Poppins',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 12,
                                                    height: 1.5,
                                                    color: Color(0xFFDEDDDD),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 5, 0, 11),
                                                width: 2,
                                                height: 2,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 31),
                  child: SizedBox(
                    width: 488,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: SizedBox(
                              width: 382.8,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                                    child: SizedBox(
                                      width: 362.2,
                                      child: Text(
                                        'Other Cities',
                                        style: GoogleFonts.getFont(
                                          'Poppins',
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12,
                                          height: 1.5,
                                          color: Color(0xFFDEDDDD),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(0, 4.1, 0, 2.2),
                                    width: 11.7,
                                    height: 11.7,
                                    child: SizedBox(
                                      width: 11.7,
                                      height: 11.7,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_14_x2.svg',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                child: Stack(
                                  children: [
                                  Positioned(
                                    left: -10,
                                    right: -12,
                                    top: -8,
                                    bottom: -9,
                                    child: Opacity(
                                      opacity: 0.5,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          gradient: LinearGradient(
                                            begin: Alignment(0, -1),
                                            end: Alignment(0, 1),
                                            colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                            stops: <double>[0, 1],
                                          ),
                                        ),
                                        child: Container(
                                          width: 156,
                                          height: 50,
                                        ),
                                      ),
                                    ),
                                  ),
                            Container(
                                      padding: EdgeInsets.fromLTRB(10, 8, 12, 9),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                margin: EdgeInsets.fromLTRB(0, 2, 10, 1),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage(
                                                        'assets/images/cloudy_weather_331175827548928.png',
                                                      ),
                                                    ),
                                                  ),
                                                  child: Container(
                                                    width: 37,
                                                    height: 30,
                                                  ),
                                                ),
                                              ),
                                              Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                    child: Text(
                                                      'Delhi',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 14,
                                                        height: 1.1,
                                                        color: Color(0xFFFFFFFF),
                                                      ),
                                                    ),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.fromLTRB(0, 0, 3.7, 0),
                                                    child: Text(
                                                      'Sunny',
                                                      style: GoogleFonts.getFont(
                                                        'Poppins',
                                                        fontWeight: FontWeight.w600,
                                                        fontSize: 10,
                                                        height: 1.3,
                                                        color: Color(0xFFDEDDDD),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 10, 0, 8),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '9',
                                                  style: GoogleFonts.getFont(
                                                    'Poppins',
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 16,
                                                    height: 0.9,
                                                    color: Color(0xFFFFFFFF),
                                                  ),
                                                ),
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 11),
                                                  width: 4,
                                                  height: 4,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                                child: Stack(
                                  children: [
                                  Positioned(
                                    left: -10,
                                    right: -12,
                                    top: -6,
                                    bottom: -4,
                                    child: Opacity(
                                      opacity: 0.5,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          gradient: LinearGradient(
                                            begin: Alignment(0, -1),
                                            end: Alignment(0, 1),
                                            colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                            stops: <double>[0, 1],
                                          ),
                                        ),
                                        child: Container(
                                          width: 156,
                                          height: 50,
                                        ),
                                      ),
                                    ),
                                  ),
                            Container(
                                      padding: EdgeInsets.fromLTRB(10, 6, 12, 4),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 0, 7, 0),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage(
                                                    'assets/images/rainy_weather_4034172333733601.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                width: 40,
                                                height: 40,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 2, 18.3, 5),
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                  child: Text(
                                                    'Kolkata',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 14,
                                                      height: 1.1,
                                                      color: Color(0xFFFFFFFF),
                                                    ),
                                                  ),
                                                ),
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Text(
                                                    'Snowy',
                                                    style: GoogleFonts.getFont(
                                                      'Poppins',
                                                      fontWeight: FontWeight.w600,
                                                      fontSize: 10,
                                                      height: 1.3,
                                                      color: Color(0xFFDEDDDD),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 12, 0, 13),
                                            child: Text(
                                              '9',
                                              style: GoogleFonts.getFont(
                                                'Poppins',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                                height: 0.9,
                                                color: Color(0xFFFFFFFF),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.fromLTRB(0, 12, 0, 24),
                                            width: 4,
                                            height: 4,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: -10,
                                    right: -12,
                                    top: -6,
                                    bottom: -5,
                                    child: Opacity(
                                      opacity: 0.5,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          gradient: LinearGradient(
                                            begin: Alignment(0, -1),
                                            end: Alignment(0, 1),
                                            colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                            stops: <double>[0, 1],
                                          ),
                                        ),
                                        child: Container(
                                          width: 156,
                                          height: 50,
                                        ),
                                      ),
                                    ),
                                  ),
                            Container(
                                    padding: EdgeInsets.fromLTRB(10, 6, 12, 5),
                                    child: Stack(
                                      clipBehavior: Clip.none,
                                      children: [
                                        SizedBox(
                                          width: double.infinity,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Expanded(
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0, 0, 8, 0),
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      image: DecorationImage(
                                                        image: AssetImage(
                                                          'assets/images/rain_331175327548872.png',
                                                        ),
                                                      ),
                                                    ),
                                                    child: Container(
                                                      height: 39,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0, 2, 1.9, 4),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                                                        child: Text(
                                                          'Haydrabad',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 14,
                                                            height: 1.1,
                                                            color: Color(0xFFFFFFFF),
                                                          ),
                                                        ),
                                                      ),
                                                      Align(
                                                        alignment: Alignment.topLeft,
                                                        child: Text(
                                                          'Rainy',
                                                          style: GoogleFonts.getFont(
                                                            'Poppins',
                                                            fontWeight: FontWeight.w600,
                                                            fontSize: 10,
                                                            height: 1.3,
                                                            color: Color(0xFFDEDDDD),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  margin: EdgeInsets.fromLTRB(0, 12, 0, 23),
                                                  height: 4,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Positioned(
                                          right: 4,
                                          bottom: 12,
                                          child: SizedBox(
                                            height: 15,
                                            child: Text(
                                              '9',
                                              style: GoogleFonts.getFont(
                                                'Poppins',
                                                fontWeight: FontWeight.w600,
                                                fontSize: 16,
                                                height: 0.9,
                                                color: Color(0xFFFFFFFF),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 26, 0),
                  child: SizedBox(
                    width: 312,
                    height: 50,
                    child: SvgPicture.asset(
                      'assets/vectors/footer_menu_3_x2.svg',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}