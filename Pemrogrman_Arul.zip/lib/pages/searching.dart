import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Searching extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment(0, -1),
          end: Alignment(0, 1),
          colors: <Color>[Color(0xFF352163), Color(0xFF331972), Color(0xFF33143C)],
          stops: <double>[0, 0.578, 1],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -86,
            top: -170.5,
            child: Opacity(
              opacity: 0.5,
              child: ClipRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                    sigmaX: 40,
                    sigmaY: 40,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      backgroundBlendMode: BlendMode.softLight,
                      image: DecorationImage(
                        image: AssetImage(
                          'assets/images/image.jpeg',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 493,
                      height: 1031,
                    ),
                  ),
                ),
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(15, 11.5, 0, 0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 17),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0.5, 6, 0),
                        child: SizedBox(
                          width: 324.6,
                          child: Text(
                            '9:41',
                            style: GoogleFonts.getFont(
                              'Poppins',
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              height: 1,
                              color: Color(0xFFFFFFFF),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 0.5),
                        child: SizedBox(
                          width: 56.4,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 6.6, 0),
                                width: 13.9,
                                height: 12,
                                child: SizedBox(
                                  width: 13.9,
                                  height: 12,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_9_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0.8, 6, 0.8),
                                width: 15,
                                height: 10.5,
                                child: SizedBox(
                                  width: 15,
                                  height: 10.5,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_17_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 3.3, 0, 1.3),
                                width: 15,
                                height: 7.5,
                                child: SizedBox(
                                  width: 15,
                                  height: 7.5,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_12_x2.svg',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 42),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: SizedBox(
                      width: 260.5,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 35,
                            height: 35,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(11.1, 11.9, 10, 13.1),
                              child: Stack(
                                clipBehavior: Clip.none,
                                children: [
                                  Container(
                                    width: 13.9,
                                    height: 10,
                                    child: SizedBox(
                                      width: 13.9,
                                      height: 10,
                                      child: SvgPicture.asset(
                                        'assets/vectors/vector_16_x2.svg',
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: -13.1,
                                    child: Container(
                                      width: 35,
                                      height: 35,
                                      child: Opacity(
                                        opacity: 0.3,
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Color(0xFFFFFFFF),
                                            borderRadius: BorderRadius.circular(5),
                                          ),
                                          child: Container(
                                            width: 35,
                                            height: 35,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 11, 0, 12),
                            child: Text(
                              'Search for City',
                              style: GoogleFonts.getFont(
                                'Poppins',
                                fontWeight: FontWeight.w600,
                                fontSize: 18,
                                height: 0.7,
                                color: Color(0xFFFFFFFF),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 41),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 14, 0),
                          child: Stack(
                            children: [
                            Positioned(
                              left: -16.6,
                              right: 0,
                              top: -11.6,
                              bottom: -5,
                              child: Opacity(
                                opacity: 0.5,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    gradient: LinearGradient(
                                      begin: Alignment(0, -1),
                                      end: Alignment(0, 1),
                                      colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                      stops: <double>[0, 1],
                                    ),
                                  ),
                                  child: Container(
                                    width: 335,
                                    height: 38,
                                  ),
                                ),
                              ),
                            ),
                      Container(
                                padding: EdgeInsets.fromLTRB(16.6, 11.6, 0, 5),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 0, 17.1, 6.1),
                                      width: 15.3,
                                      height: 15.3,
                                      child: SizedBox(
                                        width: 15.3,
                                        height: 15.3,
                                        child: SvgPicture.asset(
                                          'assets/vectors/vector_4_x2.svg',
                                        ),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.fromLTRB(0, 1.4, 0, 0),
                                      child: RichText(
                                        text: TextSpan(
                                          text: 'Bang',
                                          style: GoogleFonts.getFont(
                                            'Poppins',
                                            fontWeight: FontWeight.w400,
                                            fontSize: 15,
                                            height: 0.8,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                          children: [
                                            TextSpan(
                                              text: 'alore',
                                              style: GoogleFonts.getFont(
                                                'Poppins',
                                                fontWeight: FontWeight.w400,
                                                fontSize: 15,
                                                height: 1.3,
                                                color: Color(0xFFA4A4A4),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Stack(
                        children: [
                            Positioned(
                              left: -8,
                              right: -8,
                              top: -8,
                              bottom: -8,
                              child: Opacity(
                                opacity: 0.5,
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(50),
                                    gradient: LinearGradient(
                                      begin: Alignment(0, -1),
                                      end: Alignment(0, 1),
                                      colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                      stops: <double>[0, 1],
                                    ),
                                  ),
                                  child: Container(
                                    width: 38,
                                    height: 38,
                                  ),
                                ),
                              ),
                            ),
                      Container(
                            width: 38,
                            height: 38,
                            padding: EdgeInsets.fromLTRB(8, 8, 8, 8),
                            child: SizedBox(
                              width: 22,
                              height: 22,
                              child: SvgPicture.asset(
                                'assets/vectors/location_on_x2.svg',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 8, 11),
                  child: SizedBox(
                    height: 114,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 17, 0, 7),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Opacity(
                            opacity: 0.5,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: LinearGradient(
                                  begin: Alignment(0, -1),
                                  end: Alignment(0, 1),
                                  colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                  stops: <double>[0, 1],
                                ),
                              ),
                              child: Container(
                                width: 321,
                                height: 90,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                    'assets/images/cloudy_weather_331175827548928.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 145,
                                height: 114,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 34,
                            top: 46,
                            child: SizedBox(
                              height: 12,
                              child: Text(
                                'Surat',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 20,
                                  height: 0.6,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 34,
                            bottom: 31,
                            child: Opacity(
                              opacity: 0.7,
                              child: SizedBox(
                                height: 12,
                                child: Text(
                                  'Cloudy',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    height: 0.9,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 9),
                  child: SizedBox(
                    height: 146,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 26, 0, 30),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Opacity(
                            opacity: 0.5,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: LinearGradient(
                                  begin: Alignment(0, -1),
                                  end: Alignment(0, 1),
                                  colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                  stops: <double>[0, 1],
                                ),
                              ),
                              child: Container(
                                width: 321,
                                height: 90,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage(
                                    'assets/images/rainy_weather_4034172333733601.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 146,
                                height: 146,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            top: 55,
                            child: SizedBox(
                              height: 12,
                              child: Text(
                                'Mumbai',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 20,
                                  height: 0.6,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            bottom: 54,
                            child: Opacity(
                              opacity: 0.7,
                              child: SizedBox(
                                height: 12,
                                child: Text(
                                  'Rainy',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    height: 0.9,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 15, 13),
                  child: SizedBox(
                    height: 117,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 14, 0, 13),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Opacity(
                            opacity: 0.5,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: LinearGradient(
                                  begin: Alignment(0, -1),
                                  end: Alignment(0, 1),
                                  colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                  stops: <double>[0, 1],
                                ),
                              ),
                              child: Container(
                                width: 321,
                                height: 90,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: AssetImage(
                                    'assets/images/rain_331175327548872.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 117,
                                height: 117,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            top: 43,
                            child: SizedBox(
                              height: 12,
                              child: Text(
                                'Chennai',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 20,
                                  height: 0.6,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            bottom: 37,
                            child: Opacity(
                              opacity: 0.7,
                              child: SizedBox(
                                height: 12,
                                child: Text(
                                  'Cold',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    height: 0.9,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 4, 77),
                  child: SizedBox(
                    height: 138,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0, 21, 0, 27),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Opacity(
                            opacity: 0.5,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                gradient: LinearGradient(
                                  begin: Alignment(0, -1),
                                  end: Alignment(0, 1),
                                  colors: <Color>[Color(0xFF957DCD), Color(0xFF523D7F)],
                                  stops: <double>[0, 1],
                                ),
                              ),
                              child: Container(
                                width: 321,
                                height: 90,
                              ),
                            ),
                          ),
                          Positioned(
                            right: 0,
                            bottom: 0,
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage(
                                    'assets/images/rainy_weather_4034172333733601.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 138,
                                height: 138,
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            top: 50,
                            child: SizedBox(
                              height: 12,
                              child: Text(
                                'Manali',
                                style: GoogleFonts.getFont(
                                  'Poppins',
                                  fontWeight: FontWeight.w600,
                                  fontSize: 20,
                                  height: 0.6,
                                  color: Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 32,
                            bottom: 51,
                            child: Opacity(
                              opacity: 0.7,
                              child: SizedBox(
                                height: 12,
                                child: Text(
                                  'Snowy',
                                  style: GoogleFonts.getFont(
                                    'Poppins',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14,
                                    height: 0.9,
                                    color: Color(0xFFFFFFFF),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 14, 0),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: 300,
                      height: 50,
                      child: SvgPicture.asset(
                        'assets/vectors/footer_menu_x2.svg',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}